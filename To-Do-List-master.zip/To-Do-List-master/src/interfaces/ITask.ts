export interface ITask {
  title: string;
  description: string;
  complete: boolean;
  id: string;
}